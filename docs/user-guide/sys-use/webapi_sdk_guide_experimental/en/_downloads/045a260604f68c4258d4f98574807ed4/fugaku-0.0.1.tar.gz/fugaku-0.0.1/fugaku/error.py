# -*- coding: utf-8 -*-
"""
fugaku.error

This module contains the set of fugaku' exceptions.

"""


class FugakuClientError(Exception):
    """
    An ambiguous exception occurred during processing of the fugaku client.
    """


class NoTokenEndpoint(FugakuClientError):
    """ if token_endpoint is not set """


class NoAccessCode(FugakuClientError):
    """ if access_code is not set """
