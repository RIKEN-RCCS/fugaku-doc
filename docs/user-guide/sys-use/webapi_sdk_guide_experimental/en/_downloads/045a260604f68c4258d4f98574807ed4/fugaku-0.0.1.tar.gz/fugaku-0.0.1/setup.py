from setuptools import setup, find_packages
setup(
    name="fugaku",
    version="0.0.1",
    author="RIKEN R-CCS",
    author_email="",
    url="",
    description="A simple python library to interact with Fugaku WebAPI",
    license="",
    packages=find_packages(exclude=('tests', 'docs')),
    classifiers=[
        "Programming Language :: Python",
        "Operating System :: OS Independent",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    install_requires=[
        'python-magic',
        'requests',
        'six',
    ],
)
