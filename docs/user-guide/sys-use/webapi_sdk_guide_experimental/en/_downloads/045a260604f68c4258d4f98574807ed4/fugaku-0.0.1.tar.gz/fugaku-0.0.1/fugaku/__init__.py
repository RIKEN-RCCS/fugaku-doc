"""
A simple python library to interact with Fugaku WebAPI
"""
from fugaku.error import FugakuClientError, NoTokenEndpoint, NoAccessCode
from fugaku.client import Client

from fugaku.__version__ import __version__
