# -*- coding: utf-8 -*-
"""
fugaku.client

This module provides a client to access Fugaku WebAPI.

"""
import requests
import json
import logging
import uuid
from six.moves.urllib.parse import quote
from magic import Magic

from fugaku.error import FugakuClientError, NoTokenEndpoint, NoAccessCode
from fugaku.utils import _get_request, _post_request, _delete_request, _post_json_request
from fugaku.utils import _put_request, _put_json_request, _normalize_path

DEFAULT_CLIENT_CONFIG = {
    "client_id": "",
    "client_secret": "",
    "redirect_uri": "",
    "scope": "openid+offline_access",
    "response_type": "code"
}


class Client:
    def __init__(self, auth_code, client_config=None, provider_metadata_url=None, authorization_endpoint=None, token_endpoint=None, request_config=None):
        """
        Creates an object which is used to access resources related to the specified credentials

        Args:
            auth_code (str): the auth_code is often obtained by the user using a browser.
            client_config (dict): the client_config to be used to get access token.
            provider_metadata_url (str): the provider_metadata_url that provides IdP metadata.
            authorization_endpoint (str): the authorization_endpoint that performs user authentication.
            token_endpoint (str): the token_endpoint that provides access token, id token or refresh token.
            request_config (dict): any extra args to be passed to the HTTP requests.

        Raises:
            FugakuClientError: when token_endpoint is invalid or access_token cannot be obtained from auth_code.
        """
        logger = logging.getLogger(__name__)
        self._uuid = str(uuid.uuid1())
        self._auth_code = auth_code
        self._client_config = DEFAULT_CLIENT_CONFIG
        if client_config is not None:
            self._client_config.update(client_config)
        self._access_token = None
        self._request_config = request_config
        self._provider_metadata_url = provider_metadata_url
        self._authorization_endpoint = authorization_endpoint
        self._token_endpoint = token_endpoint

        if (token_endpoint is not None and token_endpoint != "") and \
           (authorization_endpoint is not None and authorization_endpoint != ""):
            logger.debug("authorization_endpoint{0}, token_endpoint:{1}".format(authorization_endpoint, token_endpoint))
        else:
            if provider_metadata_url is None:
                msg = "Requires parameter provider_metadata_url or endpoint pair."
                logger.warning(msg)
            else:
                self._token_endpoint = self._get_token_endpoint_url(self._provider_metadata_url)
                if self._token_endpoint is None or self._token_endpoint == "":
                    msg = "token_endpoint could not be obtained from metadata."
                    logger.error(msg)
                    raise NoTokenEndpoint(msg)

        if auth_code is None or auth_code == "":
            msg = "auth_code is required."
            if self._authorization_endpoint is not None:
                if self._client_config['client_id'] is None or self._client_config['client_id'] == "":
                    msg += "\nPlease access the following URL.\n{0}?response_type={3}&scope={4}&client_id={1}&redirect_uri={2}".format(
                        self._authorization_endpoint, "client_config['client_id']",
                        "client_config['redirect_uri']",
                        quote(self._client_config['response_type']), quote(self._client_config['scope'], safe='+'))
                else:
                    msg += "\nPlease access the following URL.\n{0}?response_type={3}&scope={4}&client_id={1}&redirect_uri={2}".format(
                        self._authorization_endpoint, quote(self._client_config['client_id']),
                        quote(self._client_config['redirect_uri']),
                        quote(self._client_config['response_type']), quote(self._client_config['scope'], safe='+'))
            logger.warning(msg)

        if self._token_endpoint is not None and self._token_endpoint != "" \
                and self._auth_code is not None and self._auth_code != "":
            logger.debug("token_endpoint:{}".format(self._token_endpoint))
            self._access_token = self._get_access_token(self._auth_code, self._token_endpoint)

    def _get_token_endpoint_url(self, provider_metadata_url):
        logger = logging.getLogger(__name__)
        response = _get_request(provider_metadata_url, request_config=self._request_config)

        if response.status_code == requests.codes.ok:
            metadata = response.json()
            self._authorization_endpoint = metadata['authorization_endpoint']
            logger.debug("authorization_endpoint:{}".format(self._authorization_endpoint))
            return metadata['token_endpoint']
        else:
            return ""

    def _get_access_token(self, auth_code, token_endpoint):
        logger = logging.getLogger(__name__)
        params = {"grant_type": "authorization_code", "code": auth_code}
        if self._client_config is not None:
            wanted_keys = ['client_id', 'client_secret', 'redirect_uri']
            config_param = {k: self._client_config[k] for k in set(wanted_keys) & set(self._client_config.keys())}

            params.update(config_param)

        response = _post_request(token_endpoint, params=params, request_config=self._request_config)

        if response.status_code == requests.codes.ok:
            self._token = response.json()
            logger.debug("token:{}".format(json.dumps(self._token, indent=4)))
            return self._token['access_token']
        else:
            logger.error("response:{}".format(response.text))
            msg = "Failed to get Access Token. http status code:{}".format(response.status_code)
            logger.error(msg)
            raise FugakuClientError(msg)

    def get_authentication_url(self, redirect_url):
        """
        Get URL for user authentication.

        If neither authorization_endpoint nor provider_metadata_url is set, only queries can be fetched.

        Args:
            redirect_url (str): the redirect URL to receive authorization code.

        Returns:
            str: return the authentication url.
        """

        logger = logging.getLogger(__name__)
        authorization_endpoint = self._authorization_endpoint
        if authorization_endpoint is None:
            if self._provider_metadata_url is None:
                logger.info("if you set provider_metadata_url you get completed url.")
            authorization_endpoint = "<authorization_endpoint>"

        if self._client_config['client_id'] is None or self._client_config['client_id'] == "":
            url = "{0}?response_type={3}&scope={4}&client_id={1}&redirect_uri={2}".format(
                authorization_endpoint, "client_config['client_id']", quote(redirect_url),
                quote(self._client_config['response_type']), quote(self._client_config['scope'], safe='+'))
        else:
            url = "{0}?response_type={3}&scope={4}&client_id={1}&redirect_uri={2}".format(
                authorization_endpoint, quote(self._client_config['client_id']), quote(redirect_url),
                quote(self._client_config['response_type']), quote(self._client_config['scope'], safe='+'))
        return url

    def _make_headers(self):
        logger = logging.getLogger(__name__)
        if self._access_token is None:
            msg = "No access token."
            logger.error(msg)
            raise NoAccessCode(msg)

        headers = {'Authorization': "Bearer " + self._access_token}
        return headers

    def _get_api_base_url(self):
        return "https://api.fugaku.r-ccs.riken.jp/"

    def get_machine_status(self):
        """
        Get status of all machines.
        Outputs the status of all machines managed by the server.

        Raises:
            NoAccessCode: when there is no access_token.

        Returns:
            requests.Response: return the request.
                               (see. https://www.fugaku.r-ccs.riken.jp/doc_root/en/user_guides/webapi/webapi/api-reference.html#get--status-)
        
        """

        headers = self._make_headers()

        url = self._get_api_base_url() + "status/"
        response = _get_request(url, headers=headers, request_config=self._request_config)

        if self._need_refresh_token(response):
            self._access_token = self._refresh_token(self._token["refresh_token"], self._token_endpoint)
            headers = self._make_headers()
            response = _get_request(url, headers=headers, request_config=self._request_config)
        return response

    def get_specific_machine_status(self, machine):
        """
        Get specified machine status.
        Output the status of the specified machine.

        Args:
            machine (str): the specific machine.
                           specify the machine name obtained by getting the status of all machines (get_machine_status).
                           Normally, specify "computer".

        Raises:
            NoAccessCode: when there is no access_token.

        Returns:
            requests.Response: return the request.
                               (see. https://www.fugaku.r-ccs.riken.jp/doc_root/en/user_guides/webapi/webapi/api-reference.html#get--status-machine)
           
        """

        headers = self._make_headers()

        url = self._get_api_base_url() + "status" + _normalize_path(machine, False)
        response = _get_request(url, headers=headers, request_config=self._request_config)

        if self._need_refresh_token(response):
            self._access_token = self._refresh_token(self._token["refresh_token"], self._token_endpoint)
            headers = self._make_headers()
            response = _get_request(url, headers=headers, request_config=self._request_config)

        return response

    def download_filedata(self, machine, file_path):
        """
        Download files.

        Args:
            machine (str): the specific machine.
            file_path (str): the download file.

        Raises:
            NoAccessCode: when there is no access_token.

        Returns:
            requests.Response: return the request.
                               (see. https://www.fugaku.r-ccs.riken.jp/doc_root/en/user_guides/webapi/webapi/api-reference.html#get--file-machine-file_path)
        """
        headers = self._make_headers()

        url = self._get_api_base_url() + "file" + _normalize_path(machine, False) + _normalize_path(file_path, False)
        request_config = {"stream": True}
        if self._request_config is not None:
            request_config.update(self._request_config)
        response = _get_request(url, headers=headers, request_config=request_config)

        if self._need_refresh_token(response):
            self._access_token = self._refresh_token(self._token["refresh_token"], self._token_endpoint)
            headers = self._make_headers()
            response = _get_request(url, headers=headers, request_config=request_config)

        return response

    def download_fileList(self, machine, file_path):
        """
        Download file list.

        Args:
            machine (str): the specific machine.
            file_path (str): the file_path to get the file list.

        Raises:
            NoAccessCode: when there is no access_token.

        Returns:
            requests.Response: return the request.
                               (see. https://www.fugaku.r-ccs.riken.jp/doc_root/en/user_guides/webapi/webapi/api-reference.html#get--file-machine-file_path)
        """

        headers = self._make_headers()

        url = self._get_api_base_url() + "file" + _normalize_path(machine, False) + _normalize_path(file_path, False) + "?view=read"
        response = _get_request(url, headers=headers, request_config=self._request_config)

        if self._need_refresh_token(response):
            self._access_token = self._refresh_token(self._token["refresh_token"], self._token_endpoint)
            headers = self._make_headers()
            response = _get_request(url, headers=headers, request_config=self._request_config)

        return response

    def upload_file(self, machine, file_path, file):
        """
        Upload file.

        Args:
            machine (str): the specific machine.
            file_path (str): the file_path specifies the upload destination.
            file (str): the upload file.

        Raises:
            NoAccessCode: when there is no access_token.

        Returns:
            requests.Response: return the request.
                               (see. https://www.fugaku.r-ccs.riken.jp/doc_root/en/user_guides/webapi/webapi/api-reference.html#post--file-machine-file_path)
        """
        headers = self._make_headers()

        url = self._get_api_base_url() + "file" + _normalize_path(machine, False) + _normalize_path(file_path, False)
        with open(file, 'r') as file_data:
            mime = Magic(mime=True)
            mime_type = mime.from_file(file)
            # "binary/octet-stream" etc
            files = {'file': (file, file_data, mime_type)}
            request_config = {"stream": True}
            if self._request_config is not None:
                request_config.update(self._request_config)

            response = _post_request(url, files=files, headers=headers, request_config=request_config)

            if self._need_refresh_token(response):
                self._access_token = self._refresh_token(self._token["refresh_token"], self._token_endpoint)
                headers = self._make_headers()
                response = _post_request(url, files=files, headers=headers, request_config=request_config)

            return response

    def modify_file(self, machine, file_path, file):
        """
        Modify file.

        Args:
            machine (str): the specific machine.
            file_path (str): the file_path specifies the upload destination.
            file (str): the upload file.

        Raises:
            NoAccessCode: when there is no access_token.

        Returns:
            requests.Response: return the request.
                               (see. https://www.fugaku.r-ccs.riken.jp/doc_root/en/user_guides/webapi/webapi/api-reference.html#put--file-machine-file_path)
        """
        headers = self._make_headers()

        url = self._get_api_base_url() + "file" + _normalize_path(machine, False) + _normalize_path(file_path, False)
        with open(file, 'r') as file_data:
            mime = Magic(mime=True)
            mime_type = mime.from_file(file)
            # "binary/octet-stream" ?
            files = {'file': (file, file_data, mime_type)}
            request_config = {"stream": True}
            if self._request_config is not None:
                request_config.update(self._request_config)
            response = _put_request(url, files=files, headers=headers, request_config=request_config)

            if self._need_refresh_token(response):
                self._access_token = self._refresh_token(self._token["refresh_token"], self._token_endpoint)
                headers = self._make_headers()
                response = _put_request(url, files=files, headers=headers, request_config=request_config)

            return response

    def get_job_status(self, machine, index=None, limit=None, status=None, jobid=None):
        """
        Get list of running jobs.

        Args:
            machine (str): the specific machine.
            index (int): the index for first record.
            limit (int): the limit for number of records.
            status (str): the status is userd filter jobs.
            jobid (str): the jobid is used to get a list of sub-jobs.

        Raises:
            NoAccessCode: when there is no access_token.

        Returns:
            requests.Response: return the request.
                               (see. https://www.fugaku.r-ccs.riken.jp/doc_root/en/user_guides/webapi/webapi/api-reference.html#get--queue-machine)
        """
        headers = self._make_headers()

        url = self._get_api_base_url() + "queue" + _normalize_path(machine, False)
        params = {}
        if index is not None:
            params['index'] = index
        if limit is not None:
            params['recourd_num'] = limit
        if status is not None:
            params['running_status'] = status
        if jobid is not None:
            params['job_id'] = jobid

        response = _get_request(url, params=params, headers=headers, request_config=self._request_config)
        if self._need_refresh_token(response):
            self._access_token = self._refresh_token(self._token["refresh_token"], self._token_endpoint)
            headers = self._make_headers()
            response = _get_request(url, params=params, headers=headers, request_config=self._request_config)

        return response

    def get_job_detail(self, machine, jobid):
        """
        Get detailed job information.

        Args:
            machine (str): the specific machine.
            jobid (str): the jobid is used to get a list of sub-jobs.

        Raises:
            NoAccessCode: when there is no access_token.

        Returns:
            requests.Response: return the request.
                               (see. https://www.fugaku.r-ccs.riken.jp/doc_root/en/user_guides/webapi/webapi/api-reference.html#get--queue-machine-jobid)
        """
        headers = self._make_headers()

        url = self._get_api_base_url() + "queue" + _normalize_path(machine, False) + _normalize_path(jobid, False)
        response = _get_request(url, headers=headers, request_config=self._request_config)

        if self._need_refresh_token(response):
            self._access_token = self._refresh_token(self._token["refresh_token"], self._token_endpoint)
            headers = self._make_headers()
            response = _get_request(url, headers=headers, request_config=self._request_config)

        return response

    def make_Jobscript(self, machine, filename, script):
        """
        Generate job execution script.

        Args:
            machine (str): the specific machine.
            filename (str): the filename is file path of the script file on the target machine.
            script (str): the script is used to create job exection script.

        Raises:
            NoAccessCode: when there is no access_token.

        Returns:
            requests.Response: return the request.
                               (see. https://www.fugaku.r-ccs.riken.jp/doc_root/en/user_guides/webapi/webapi/api-reference.html#put--queue-machine-jobscript)
        """
        headers = self._make_headers()

        url = self._get_api_base_url() + "queue" + _normalize_path(machine, False) + "/jobscript"
        param = {"filename": filename, "script": script}
        response = _put_json_request(url, params=param, headers=headers, request_config=self._request_config)

        if self._need_refresh_token(response):
            self._access_token = self._refresh_token(self._token["refresh_token"], self._token_endpoint)
            headers = self._make_headers()
            response = _put_json_request(url, params=param, headers=headers, request_config=self._request_config)

        return response

    def get_job_status_sacct(self, machine, index=None, limit=None, status=None, jobid=None):
        """
        Get list of completed jobs.

        Obtain a list of jobs completed within 24 hours from the job scheduler on the target machine.

        Args:
            machine (str): the specific machine.
            index (int): the index for first record.
            limit (int): the limit for number of records.
            status (str): the status is userd filter jobs.
            jobid (str): the jobid is used to get a list of sub-jobs.

        Raises:
            NoAccessCode: when there is no access_token.

        Returns:
            requests.Response: return the request.
                               (see. https://www.fugaku.r-ccs.riken.jp/doc_root/en/user_guides/webapi/webapi/api-reference.html#get--queue-machine-sacct)
        """
        headers = self._make_headers()

        url = self._get_api_base_url() + "queue" + _normalize_path(machine, False) + "/sacct"
        params = {}
        if index is not None:
            params['index'] = index
        if limit is not None:
            params['recourd_num'] = limit
        if status is not None:
            params['running_status'] = status
        if jobid is not None:
            params['job_id'] = jobid

        response = _get_request(url, params=params, headers=headers, request_config=self._request_config)
        if self._need_refresh_token(response):
            self._access_token = self._refresh_token(self._token["refresh_token"], self._token_endpoint)
            headers = self._make_headers()
            response = _get_request(url, params=params, headers=headers, request_config=self._request_config)

        return response

    def submit_job(self, machine, jobfile=None, jobscript=None, qopt=None):
        """
        Submit a job.

        Args:
            machine (str): the specific machine.
            jobfile (str): the jobfile to submit.
            jobscript (str): the jobscript to submit.
            qopt (str): the qopt to be passed to the Job Scheduler.

        Raises:
            NoAccessCode: when there is no access_token.

        Returns:
            requests.Response: return the request.
                               (see. https://www.fugaku.r-ccs.riken.jp/doc_root/en/user_guides/webapi/webapi/api-reference.html#post--queue-machine)
        """

        headers = self._make_headers()

        url = self._get_api_base_url() + "queue" + _normalize_path(machine)
        params = {}
        if jobfile is not None:
            params['jobfile'] = jobfile
        if jobscript is not None:
            params['jobscript'] = jobscript
        if qopt is not None:
            params['qopt'] = qopt

        response = _post_json_request(url, params=params, headers=headers, request_config=self._request_config)
        if self._need_refresh_token(response):
            self._access_token = self._refresh_token(self._token["refresh_token"], self._token_endpoint)
            headers = self._make_headers()
            response = _post_json_request(url, params=params, headers=headers, request_config=self._request_config)

        return response

    def cancel_job(self, machine, jobid):
        """
        Cancel a job.

        Args:
            machine (str): the specific machine.
            jobid (str): the jobid to cancel.

        Raises:
            NoAccessCode: when there is no access_token.

        Returns:
            requests.Response: return the request.
                               (see. https://www.fugaku.r-ccs.riken.jp/doc_root/en/user_guides/webapi/webapi/api-reference.html#delete--queue-machine-jobid)
        """
        headers = self._make_headers()

        url = self._get_api_base_url() + "queue" + _normalize_path(machine, False) + _normalize_path(jobid, False)
        response = _delete_request(url, headers=headers, request_config=self._request_config)

        if self._need_refresh_token(response):
            self._access_token = self._refresh_token(self._token["refresh_token"], self._token_endpoint)
            headers = self._make_headers()
            response = _delete_request(url, headers=headers, request_config=self._request_config)

        return response

    def exec_command(self, machine, command):
        """
        Execute a command.

        Args:
            machine (str): the specific machine.
            command (str): the command to exec.

        Raises:
            NoAccessCode: when there is no access_token.

        Returns:
            requests.Response: return the request.
                               (see. https://www.fugaku.r-ccs.riken.jp/doc_root/en/user_guides/webapi/webapi/api-reference.html#post--command-machine)
        """
        headers = self._make_headers()

        url = self._get_api_base_url() + "command" + _normalize_path(machine)
        params = {"command": command}

        response = _post_json_request(url, params=params, headers=headers, request_config=self._request_config)

        if self._need_refresh_token(response):
            self._access_token = self._refresh_token(self._token["refresh_token"], self._token_endpoint)
            headers = self._make_headers()
            response = _post_json_request(url, params=params, headers=headers, request_config=self._request_config)

        return response

    def get_disk_usage(self, machine):
        """
        Get disk usage.

        Args:
            machine (str): the specific machine.

        Raises:
            NoAccessCode: when there is no access_token.

        Returns:
            requests.Response: return the request.
        """

        headers = self._make_headers()

        url = self._get_api_base_url() + "usage" + _normalize_path(machine) + "disk/"
        response = _get_request(url, headers=headers, request_config=self._request_config)

        if self._need_refresh_token(response):
            self._access_token = self._refresh_token(self._token["refresh_token"], self._token_endpoint)
            headers = self._make_headers()
            response = _get_request(url, headers=headers, request_config=self._request_config)
        return response

    def _refresh_token(self, refresh_token, token_endpoint):
        logger = logging.getLogger(__name__)
        params = {"grant_type": "refresh_token", "refresh_token": refresh_token}
        if self._client_config is not None:
            wanted_keys = ['client_id', 'client_secret', 'redirect_uri']
            config_param = {k: self._client_config[k] for k in set(wanted_keys) & set(self._client_config.keys())}

            params.update(config_param)

        response = _post_request(token_endpoint, params=params, request_config=self._request_config)

        if response.status_code == requests.codes.ok:
            self._token = response.json()
            logger.debug("token:{}".format(json.dumps(self._token, indent=4)))
            return self._token['access_token']
        else:
            logger.error("response:{}".format(response.text))
            msg = "Failed to Refresh Token. http status code:{}".format(response.status_code)
            logger.error(msg)
            raise FugakuClientError(msg)

    def _need_refresh_token(self, response):
        logger = logging.getLogger(__name__)
        logger.debug("response {}".format(response.text))
        if response.status_code == 401 and self._token:
            if response.headers["WWW-Authenticate"] and "token expired or not valid" in response.headers["WWW-Authenticate"]:
                return True
        elif response.status_code == 403 and self._token:
            return True
        return False
