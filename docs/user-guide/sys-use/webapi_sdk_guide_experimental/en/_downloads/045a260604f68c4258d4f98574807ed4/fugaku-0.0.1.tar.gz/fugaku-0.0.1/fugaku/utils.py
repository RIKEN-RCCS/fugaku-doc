# -*- coding: utf-8 -*-
"""
fugaku.utils

This module provides utility functions that are used within fugaku.

"""
import requests
import logging
from six.moves.urllib.parse import quote


def _get_request(url, headers=None, params=None, request_config=None):
    logger = logging.getLogger(__name__)
    if request_config is not None:
        response = requests.get(url, params=params, headers=headers, **request_config)
    else:
        response = requests.get(url, params=params, headers=headers)

    if logger.isEnabledFor(logging.DEBUG):
        logger.debug("url:{},response:{}".format(url, response))

    return response


def _post_request(url, headers=None, params=None, files=None, request_config=None):
    logger = logging.getLogger(__name__)
    if request_config is not None:
        response = requests.post(url, data=params, files=files, headers=headers, **request_config)
    else:
        response = requests.post(url, data=params, files=files, headers=headers)

    if logger.isEnabledFor(logging.DEBUG):
        logger.debug("url:{},params:{},response:{}".format(url, params, response))

    return response


def _post_json_request(url, headers=None, params=None, request_config=None):
    logger = logging.getLogger(__name__)
    if request_config is not None:
        response = requests.post(url, json=params, headers=headers, **request_config)
    else:
        response = requests.post(url, json=params, headers=headers)

    if logger.isEnabledFor(logging.DEBUG):
        logger.debug("url:{},params:{},response:{}".format(url, params, response))

    return response


def _put_request(url, headers=None, params=None, files=None, request_config=None):
    logger = logging.getLogger(__name__)
    if request_config is not None:
        response = requests.put(url, data=params, files=files, headers=headers, **request_config)
    else:
        response = requests.put(url, data=params, files=files, headers=headers)

    if logger.isEnabledFor(logging.DEBUG):
        logger.debug("url:{},params:{},response:{}".format(url, params, response))

    return response


def _put_json_request(url, headers=None, params=None, files=None, request_config=None):
    logger = logging.getLogger(__name__)
    if request_config is not None:
        response = requests.put(url, json=params, files=files, headers=headers, **request_config)
    else:
        response = requests.put(url, json=params, files=files, headers=headers)

    if logger.isEnabledFor(logging.DEBUG):
        logger.debug("url:{},params:{},response:{}".format(url, params, response))

    return response


def _delete_request(url, headers=None, request_config=None):
    logger = logging.getLogger(__name__)
    if request_config is not None:
        response = requests.delete(url, headers=headers, **request_config)
    else:
        response = requests.delete(url, headers=headers)

    if logger.isEnabledFor(logging.DEBUG):
        logger.debug("url:{},response:{}".format(url, response))

    return response


def _normalize_path(url, with_tail_slash=True):
    result = ""
    if url is not None:
        if not url.startswith("/"):
            result = "/" + url
        else:
            result = url

        if with_tail_slash and not result.endswith("/"):
            result = result + "/"

    return quote(result)
