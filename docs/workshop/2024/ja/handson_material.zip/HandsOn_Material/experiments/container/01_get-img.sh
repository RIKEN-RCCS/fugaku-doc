#!/bin/bash
#PJM -g hp240486
#PJM --rsc-list [resource_group]
#PJM --rsc-list "node=1"
#PJM --rsc-list "elapse=00:03:00"
#PJM --rsc-list "node-mem=28Gi"
#PJM --rsc-list "freq=2200,eco_state=2"
#PJM --rsc-list "jobenv=singularity"
#PJM -x PJM_LLIO_GFSCACHE=/vol0006
#PJM -o  "%n.%j.out"
#PJM -e  "%n.%j.err"
#PJM -s



date

echo "[CHECK VERSION]"
ver=0
ver=$(singularity --version)
echo ${ver}
ver=$(echo ${ver} |sed -e 's|^.*version||g' |sed -e 's|\..*$||g')

echo " "
echo "[PULL EXISTED CONTAINER]"
if [ ${ver} -ge 4 ] ; then
   singularity pull --arch arm64 ubuntu2404.sif docker://ubuntu:24.04 # for 4.x
elif [ ${ver} -eq 3 ]; then
   singularity pull ubuntu2404.sif docker://ubuntu:24.04 # for 3.x
else
  echo "unknown"
  exit 1
fi

echo " "
echo "[CONFIRM SIF IMAGE]"
ls -la

echo " "
echo "[CHECK THE ORIGINAL OS INFORMATION]"
uname -a
whoami
cat /etc/os-release

echo " "
echo "[CHECK THE CONTAINER OS INFORMATION]"
singularity exec ubuntu2404.sif uname -a
singularity exec ubuntu2404.sif whoami
singularity exec ubuntu2404.sif cat /etc/os-release

# If you do not need to keep the image, you can remove it.
#echo " "
#echo "[BYE]"
#rm -v ubuntu2404.sif
