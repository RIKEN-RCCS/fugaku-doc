#!/bin/bash
#PJM -g hp240486
#PJM --rsc-list [resource_group]
#PJM --rsc-list "node=1"
#PJM --rsc-list "elapse=00:03:00"
#PJM --rsc-list "node-mem=28Gi"
#PJM --rsc-list "jobenv=singularity"
#PJM --rsc-list "freq=2200,eco_state=2"
#PJM -x PJM_LLIO_GFSCACHE=/vol0006
#PJM -o  "%n.%j.out"
#PJM -e  "%n.%j.err"
#PJM -s



if [ ! -f "ubuntu2404.sif" ] ; then
   echo "No the image file. Please perform 01_get-img.sh at first."
   exit 1
fi

# Current directory
CWD=$(pwd) 

# Control group permission
FLAG_NOGRP=0  # Default
#---IMPORTANT-REMARK--start-
# Depending on kinds of file systems, you need to set --no-setgroups  
# owing to permission.
# See https://github.com/sylabs/singularity/discussions/1810
# Option "--no-setgroups" is available for singularity 3.11 and later. 
#FLAG_NOGRP=1 
#---IMPORTANT-REMARK--end-
if [ ${FLAG_NOGRP} -eq 1 ] ; then
   FAKERTOPT=$(echo "--fakeroot --writable --no-setgroups")
else
   FAKERTOPT=$(echo "--fakeroot --writable")
fi

# Temporary files in sandbox
#---IMPORTANT-REMARK--start-
# Depending on kinds of file systems, you need to properly set the directory 
# for sandbox. Please ask the administrator of the file system in your machine.
#---IMPORTANT-REMARK--end-
SDBOX_DIR=  # Please specify the location of a proper storage for sandbox (e.g., a local storage on a node).
export TMPDIR=${SDBOX_DIR}

# Create image from sandbox, based on ubuntu24.04
SDBOX=${SDBOX_DIR}/ub-sb
singularity build --sandbox ${SDBOX} ubuntu2404.sif
singularity exec ${FAKERTOPT} ${SDBOX} apt-get update 

# If setting timezone is failed, you can comment out the following execution.
# We set TZ as Asia/Tokyo. You can change it depending on your environment.
singularity exec ${FAKERTOPT} ${SDBOX} bash -c \
'env DEBIAN_FRONTEND=noninteractive apt-get install -y tzdata && \
ln -vsf /usr/share/zoneinfo/Asia/Tokyo /etc/localtime && \
dpkg-reconfigure --frontend noninteractive tzdata'


singularity exec ${FAKERTOPT} ${SDBOX} apt-get install -y gcc 
singularity exec ${FAKERTOPT} ${SDBOX} apt-get install -y gfortran
singularity exec ${FAKERTOPT} ${SDBOX} apt-get install -y make
singularity exec ${FAKERTOPT} ${SDBOX} apt clean
singularity exec ${FAKERTOPT} ${SDBOX} rm -vrf /var/lib/apt/lists/*
singularity build my-ubuntu2404.sif ${SDBOX}

# Delete sandbox
rm -vrf ${SDBOX}
