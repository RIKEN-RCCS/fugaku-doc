# Experimental samples: Create container image using Singularity

## Reference
* Presentation by Kenji Morimoto in PCCC22; [https://www.pccluster.org/ja/event/pccc22/program/](https://www.pccluster.org/ja/event/pccc22/program/)
* [Virtual Fugaku](https://www.r-ccs.riken.jp/en/fugaku/virtual-fugaku/)

## Quick instruction
### How to execute
```shell
# To get pre-built container image of Ubuntu for arm64 (i.e., aarch64).
$ pjsub 01_get-img.sh  
# To create your own SIF, based on Ubuntu container.
$ pjsub 02_create-sif.sh
# To execute a simple program using your own SIF.
$ pjsub 03_run-mysif.sh
```

### Important remark
* When using singularityAs for `pjsub`, `#PJM -L "jobenv=singularity"` should be set.
* Handling a container strongly depends on kinds of the file systems in your machine. In particular, you will need to properly set `FLAG_NOGRP` and `SDBOX_DIR` in `02_create-sif.sh`.
* Before trying this sample, we suggest that you check the document on the file system in your machine.
