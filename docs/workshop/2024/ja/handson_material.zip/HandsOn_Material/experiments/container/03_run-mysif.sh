#!/bin/bash
#PJM -g hp240486
#PJM --rsc-list [resource_group]
#PJM --rsc-list "node=1"
#PJM --rsc-list "elapse=00:03:00"
#PJM --rsc-list "node-mem=28Gi"
#PJM --rsc-list "jobenv=singularity"
#PJM --rsc-list "freq=2200,eco_state=2"
#PJM -x PJM_LLIO_GFSCACHE=/vol0006
#PJM -o  "%n.%j.out"
#PJM -e  "%n.%j.err"



SIF=my-ubuntu2404.sif
if [ ! -f ${SIF} ] ; then
   echo "No the image file. Please perform 02_create-sif.sh at first."
   exit 1
fi

# Current directory
CWD=$(pwd) 

# Write sample C source file in the current directory
SRC=sample.c
{
cat <<EOF
#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

int main (int argc, char **argv)
{
   int nt = omp_get_max_threads();
   #pragma omp parallel shared(nt)
   {
     int tid = omp_get_thread_num();
     #pragma omp critical
     {
        printf("Hello. I am %d-th thread of %d threads.\n", tid, nt);
     }
   }
   return EXIT_SUCCESS;
}
EOF
} > ${SRC}

# Run 
singularity exec --bind ${CWD} ${SIF} gcc --version
singularity exec --bind ${CWD} ${SIF} gcc -g -O2 -fopenmp ${SRC}
singularity exec --bind ${CWD} ${SIF} env OMP_NUM_THREADS=12 ./a.out
singularity exec --bind ${CWD} ${SIF} env OMP_NUM_THREADS=1 ./a.out &> log.nt1
singularity exec --bind ${CWD} ${SIF} env OMP_NUM_THREADS=48 ./a.out &> log.nt48

rm -v ${SRC}
