#!/bin/bash 
#PJM -g hp240486
#PJM --rsc-list [resource_group]
#PJM --rsc-list "node=1,elapse=00:03:00"
#PJM --rsc-list "node-mem=28Gi"
#PJM --rsc-list "freq=2200, eco_state=2"
#PJM --mpi "max-proc-per-node=48"
#PJM --mpi "rank-map-bychip"
#PJM -x PJM_LLIO_GFSCACHE=/vol0006
#---#PJM --mpi "rank-map-bynode"
#---#PJM --mpi "rank-map-hostfile"
#PJM -N "imb"
#PJM -o  "%n.%j.out"
#PJM -e  "%n.%j.err"
#PJM -s


ulimit -s unlimited

NPROCS=2

# Do not create empty stdout and stderr files.
export PLE_MPI_STD_EMPTYFILE="off"

EXE=[src_dir]/IMB-MPI1 #[src_dir] is your installed location of Intel MPI benchmark

echo "single: Use MPI_Init"
MPIEXE=$(echo "mpiexec -np ${NPROCS} ")
MPIIN=
MPIOUT=$(echo "--stdout-proc mpi1-0.out ")
MPIERR=$(echo "--stderr-proc mpi1-0.err ")
${MPIEXE} ${MPIIN} ${MPIOUT} ${MPIERR} ${EXE} -thread_level single PingPong

echo "funneled: Use MPI_Init_thread"
MPIEXE=$(echo "mpiexec -np ${NPROCS} ")
MPIIN=
MPIOUT=$(echo "--stdout-proc mpi1-1.out ")
MPIERR=$(echo "--stderr-proc mpi1-1.err ")
${MPIEXE} ${MPIIN} ${MPIOUT} ${MPIERR} ${EXE} -thread_level funneled PingPong

echo "serialized: Use MPI_Init_thread"
MPIEXE=$(echo "mpiexec -np ${NPROCS} ")
MPIIN=
MPIOUT=$(echo "--stdout-proc mpi1-2.out ")
MPIERR=$(echo "--stderr-proc mpi1-2.err ")
${MPIEXE} ${MPIIN} ${MPIOUT} ${MPIERR} ${EXE} -thread_level serialized PingPong

echo "multiple: Use MPI_Init_thread"
MPIEXE=$(echo "mpiexec -np ${NPROCS} ")
MPIIN=
MPIOUT=$(echo "--stdout-proc mpi1-3.out ")
MPIERR=$(echo "--stderr-proc mpi1-3.err ")
${MPIEXE} ${MPIIN} ${MPIOUT} ${MPIERR} ${EXE} -thread_level multiple PingPong
/work/04/gt23/t23000/hands-on/ver2.1/05_mpi-openmp/02_thread-level/use_imb
../../../04_pure-mpi/00_imb/IMB-v2021.3/
