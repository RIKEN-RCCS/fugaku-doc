```shell
$ bash 01collect.sh
$ ls
stat.fj_zfill.close.csv  stat.fj_zfill.spread.csv  (...)
$ python3 02viz.py stat.fj_zfill.close.csv Triad stat.fj_zfill.spread.csv
$ ls
stat.Triad.png (...)
```
