```shell
$ bash 01collect.sh
$ ls
stat.fj.csv  stat.fj_zfill.sv  (...)
$ python3 02viz.py stat.fj.csv Triad stat.fj_zfill.csv
$ ls
stat.Triad.png (...)
```
