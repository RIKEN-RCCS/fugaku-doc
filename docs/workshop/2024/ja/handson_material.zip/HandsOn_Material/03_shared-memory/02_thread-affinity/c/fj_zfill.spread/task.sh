#!/bin/bash
#PJM -g hp240486
#PJM --rsc-list [resource_group]
#PJM --rsc-list "node=1"
#PJM --rsc-list "elapse=00:06:00"
#PJM --rsc-list "node-mem=28Gi"
#PJM --rsc-list "freq=2200, eco_state=2"
#PJM -x PJM_LLIO_GFSCACHE=/vol0006
#PJM -N "strm"
#PJM -o  "%n.%j.out"
#PJM -e  "%n.%j.err"
#PJM -s
env NTHREADS=1 bash run.sh
env NTHREADS=4 TAFF=spread bash run.sh
env NTHREADS=8 TAFF=spread bash run.sh
env NTHREADS=12 TAFF=spread bash run.sh
env NTHREADS=24 TAFF=spread bash run.sh
env NTHREADS=48 TAFF=spread bash run.sh
