#!/bin/bash
#PJM --gname rist-f 
#PJM -L "node=12,elapse=00:08:00,freq=2200,eco_state=2"
#PJM --mpi "max-proc-per-node=4" 
#PJM --mpi "rank-map-bychip"
#PJM --name "tbi"
#PJM --out  "%n.%j.out"
#PJM --err  "%n.%j.err"
#PJM --stats
#PJM -x PJM_LLIO_GFSCACHE=/vol0004

ND=12
PPN=4
NP=$((ND*PPN))

EXE=../run.x

export OMPI_MCA_plm_ple_memory_allocation_policy=localalloc # default
export OMPI_MCA_plm_ple_memory_numanode_assign_policy=share_cyclic # default
export OMPI_MCA_mpi_print_stats=2  #1
export OMPI_MCA_mpi_print_stats_ranks=0,1 # effective only if mpi_print_stats=2 or 4
#export OMPI_MCA_coll=^tbi
#export OMPI_MCA_coll_tbi_intra_node_reduction=3 #default
#export OMPI_MCA_coll_base_reduce_commute_safe=0 #default

ulimit -s unlimited
MPIEXE=$(echo "mpiexec -np ${NP} ")
MPIIN=
MPIOUT=$(echo "-stdout-proc ./job%j/%/128r/out ") 
MPIERR=$(echo "-stderr-proc ./job%j/%/128r/err ")

${MPIEXE} ${MPIIN} ${MPIOUT} ${MPIERR} ${EXE}
