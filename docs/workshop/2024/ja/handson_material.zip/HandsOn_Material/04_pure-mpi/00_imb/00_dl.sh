#!/bin/bash

BRANCH="IMB-v2021.3"

git clone  -b ${BRANCH} https://github.com/intel/mpi-benchmarks.git ${BRANCH}
