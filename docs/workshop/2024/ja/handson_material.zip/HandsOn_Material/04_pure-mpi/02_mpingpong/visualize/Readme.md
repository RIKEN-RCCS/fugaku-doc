```shell
$ bash 01convert.sh
$ ls
out.cs32cl256_P48Q2.csv  out.cs32cl256_P4Q2.csv  (...)
$ python3 02viz.py out.cs32cl256_P4Q2.csv out.cs32cl256_P48Q2.csv
$ ls
comp.bw.png  comp.lt.png  (...)
```
