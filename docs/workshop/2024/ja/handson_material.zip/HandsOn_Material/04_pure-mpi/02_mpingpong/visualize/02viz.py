#!/usr/bin/env python3
# Copyright 2024 Research Organization for Information Science and Technology 
import sys
import textwrap
import numpy as np
import matplotlib 
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import pandas as pd

compiler_version='[fj4.11.2]'

### for boost eco mode
power_mode='freq=2200, eco_state=2'

### for normal mode
# power_mode='freq=2000, eco_state=0'

## command-line option
argc = len(sys.argv)

if argc != 3:
     usage_msg = '''
     [usage] test.py (arg1) (arg2)
     (arg1): input file (char; csv)
     (arg2): input file for comparison (char; csv)
     '''
     print(textwrap.dedent(usage_msg).strip())
     sys.exit(0)

data = pd.read_csv(sys.argv[1],sep=',',header=0)
fltp = ( data['bytes'] != 0 )
data_fltp = data[fltp]

data2 = pd.read_csv(sys.argv[2],sep=',',header=0)
fltp2 = ( data2['bytes'] != 0 )
data2_fltp = data2[fltp2]

## plot latency
plt.clf()
plt.rc('figure',figsize=(5.4,4.1)) # figsize=(6.4,4.8)
plt.rc('figure',dpi=150)
fig,ax = plt.subplots()

ax.set_xscale("log")
ax.set_yscale("log")

yminv = data2_fltp['t_max[usec]'].min()
yminv = yminv*0.35
ymaxv = data2_fltp['t_max[usec]'].max() 
ymaxv = ymaxv*2.3
ax.set_ylim(bottom=yminv,top=ymaxv)

xvar = data_fltp['bytes']
yvar = data_fltp['t_max[usec]']
lb = 'P' + str(data_fltp['ngrp'].iloc[0]) + 'Q' + str(data_fltp['np'].iloc[0])
ax.plot(xvar,yvar,linestyle='--',linewidth='1.2',marker='o',\
        label=lb,color='#ff00ff',markerfacecolor='none')
xvar = data2_fltp['bytes']
yvar = data2_fltp['t_max[usec]']
lb2 = 'P' + str(data2_fltp['ngrp'].iloc[0]) + 'Q' + str(data2_fltp['np'].iloc[0])
ax.plot(xvar,yvar,linestyle='--',linewidth='1.2',marker='s',\
        label=lb2,color='#32cd32',markerfacecolor='none')

ax.legend()
ax.set_xlabel('Message length (bytes)')
ax.set_ylabel('Elapsed time (max) ($\\mu$s)')
# ax.set_title('IMB-1:Multiple Pingpong b/w 2 nodes in FX1000 (fj4.11.1)',fontsize=9)
ax.set_title('IMB-1:Multiple Pingpong b/w 2 nodes in Fugaku ' + compiler_version,fontsize=9)
ax.grid(which='both',axis='y',color='gray',linestyle='--',linewidth=0.6)
ax.grid(which='major',axis='x',color='gray',linestyle='--',linewidth=0.6)
ax.vlines(4096,yminv,ymaxv,colors='gray',linestyles='solid',linewidth=1.3)
ax.vlines(65536,yminv,ymaxv,colors='gray',linestyles='solid',linewidth=1.3)
ax.vlines(1048526,yminv,ymaxv,colors='gray',linestyles='solid',linewidth=1.3)

plt.text(4.0e+3, yminv*2, \
         'Cache-size=32MB, Cache-line=256B',\
         fontsize=7.5,bbox=dict(boxstyle='round',facecolor='wheat',alpha=0.5))

ofn = 'comp'
ofn = ofn + '.lt' +'.png'
plt.savefig(ofn,format='png')

## plot bandwidth 
plt.clf()
plt.rc('figure',figsize=(5.4,4.1)) # figsize=(6.4,4.8)
plt.rc('figure',dpi=150)
fig,ax = plt.subplots()

ax.set_xscale("log")
ax.set_yscale("log")

yminv = data_fltp['Mbytes/sec'].min()
yminv = yminv*0.35
ymaxv = data_fltp['Mbytes/sec'].max() 
ymaxv = ymaxv*2.3
ax.set_ylim(bottom=yminv,top=ymaxv)

xvar = data_fltp['bytes']
yvar = data_fltp['Mbytes/sec']
ax.plot(xvar,yvar,linestyle='--',linewidth='1.2',marker='o',\
        label='P4Q2',color='#ff00ff',markerfacecolor='none')
xvar = data2_fltp['bytes']
yvar = data2_fltp['Mbytes/sec']
ax.plot(xvar,yvar,linestyle='--',linewidth='1.2',marker='s',\
        label='P48Q2',color='#32cd32',markerfacecolor='none')

ax.legend()
ax.set_xlabel('Message length (bytes)')
ax.set_ylabel('Bandwidth (MB/s)')
# ax.set_title('IMB-1:Multiple Pingpong b/w 2 nodes in FX1000 (fj4.11.1)',fontsize=9)
ax.set_title('IMB-1:Multiple Pingpong b/w 2 nodes in Fugaku ' + compiler_version,fontsize=9)
ax.grid(which='both',axis='y',color='gray',linestyle='--',linewidth=0.6)
ax.grid(which='major',axis='x',color='gray',linestyle='--',linewidth=0.6)
ax.vlines(4096,yminv,ymaxv,colors='gray',linestyles='solid',linewidth=1.3)
ax.vlines(65536,yminv,ymaxv,colors='gray',linestyles='solid',linewidth=1.3)
ax.vlines(1048526,yminv,ymaxv,colors='gray',linestyles='solid',linewidth=1.3)

plt.text(4.0e+3, yminv*2, \
         'Cache-size=32MB, Cache-line=256B',\
         fontsize=7.5,bbox=dict(boxstyle='round',facecolor='wheat',alpha=0.5))

ofn = 'comp'
ofn = ofn + '.bw' +'.png'
plt.savefig(ofn,format='png')
