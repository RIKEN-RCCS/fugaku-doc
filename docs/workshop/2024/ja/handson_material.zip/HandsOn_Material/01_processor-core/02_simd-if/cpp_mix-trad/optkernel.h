// Copyright 2024 Research Organization for Information Science and Technology
#ifndef OPTKERNEL_H
#define OPTKERNEL_H

void gen_listvec_trad (int, double, double, double, double, 
   int * __restrict__, double * __restrict__, 
   double * __restrict__ , double * __restrict__, 
   int * __restrict__ , double * __restrict__ , 
   double * __restrict__ , double * __restrict__, 
   double * __restrict__ , int &);

#endif // OPTKERNEL_H
