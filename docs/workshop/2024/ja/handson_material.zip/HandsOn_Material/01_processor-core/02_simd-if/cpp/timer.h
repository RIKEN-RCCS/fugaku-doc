// Copyright 2024 Research Organization for Information Science and Technology
#ifndef TIMER_H
#define TIMER_H

double get_elp_time ();

#endif // TIMER_H
