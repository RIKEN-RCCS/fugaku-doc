```shell
$ bash 01collect.sh
$ ls
stat.csv (...)
$ python3 02viz.py stat.csv
$ ls
stat.png (...)
```
