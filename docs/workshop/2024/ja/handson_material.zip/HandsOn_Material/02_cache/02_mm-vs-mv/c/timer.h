/* Copyright 2024 Research Organization for Information Science and Technology */
#pragma once
double get_elp_time() ;
double get_cpu_time() ;
