#!/usr/bin/env/python3
# Copyright 2025 Research Organization for Information Science and Technology
import sys
import textwrap
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

compiler_version='[fj4.11.2]'

### for boost eco mode
power_mode='freq=2200, eco_state=2'
peak_gfs=2.2 * 8 * 2 * 1

### for normal mode
# power_mode='freq=2000, eco_state=0'
# peak_gfs=2.0 * 8 * 2 * 2

### command-line option
argc = len(sys.argv)

if argc != 2:
    usage_msg = '''
    [usage] viz.py (arg1)
    (arg1): input file name (char; csv)
    '''
    print(textwrap.dedent(usage_msg).strip())
    sys.exit(0)

### filtering
data = pd.read_csv(sys.argv[1], sep=',', header=0)

### kernel list
kerlst = ['simple', 'DGEMM', 'Rep-DGEMV']
collst = ['#1d90ff', '#228b22', '#dc143c']
mrklst = ['o', '^', 's']


### setting
vname = 'matrix dimension'
xminv = 3
xmaxv = 1530 # 2030
l2cmg_matrix_size = np.sqrt( 8.0 * 1024 * 1024 / 3.0 / 8.0)

### plot
plt.clf()
plt.rc('figure', figsize=(10.5,3.7))  #(6.4,4.8)[inch]
plt.rc('figure', dpi=150)

fig,(ax1,ax2) = plt.subplots(nrows=1, ncols=2, sharey=False)
ax1.set_xlabel(vname, fontsize='9')
ax1.set_xlim(left=xminv, right=xmaxv)
ax2.set_xlabel(vname, fontsize='9')
ax2.set_xlim(left=xminv, right=xmaxv)

# ax1: elapse time
yminv = 0.0
ymaxv = 0.8
ax1.set_ylim(bottom=yminv, top=ymaxv)
ax1.set_ylabel('Elapse Time/NITR (sec.)', fontsize='9')
ax1.axvline(l2cmg_matrix_size, 0.0, 1.0, linewidth='0.8', color='gray')
ax1.axvline(l2cmg_matrix_size*2, 0.0, 1.0, linewidth='0.8', color='gray')

# ax2: GFlops
yminv = 0.0
# ymaxv = peak_gfs * 1.17
ymaxv = (2.0 * 8 * 2 * 2) * 1.17
ax2.set_ylim(bottom=yminv, top=ymaxv)
ax2.set_ylabel('GFlops/s', fontsize='9')
ax2.axhline(y=peak_gfs, xmin=0, xmax=xmaxv, linewidth='2', color='red')
ax2.axvline(l2cmg_matrix_size, 0.0, 1.0, linewidth='0.8', color='gray')
ax2.axvline(l2cmg_matrix_size*2, 0.0, 1.0, linewidth='0.8', color='gray')

for (kl, cl, ml) in zip(kerlst, collst, mrklst):
    fltp = ( data['kernel'] == kl )
    data_fltp = data[fltp]

    xt = data_fltp['NSIZE']
    yt = data_fltp['Elapsed_time_sec'] / data_fltp['NITR']
    ax1.plot(xt, yt, color=cl, label=kl, linestyle='--', linewidth='1.0', marker=ml, markerfacecolor='none')

    xt = data_fltp['NSIZE']
    yt = data_fltp['Gflop/s']
    ax2.plot(xt, yt, color=cl, label=kl, linestyle='--', linewidth='1.0', marker=ml, markerfacecolor='none')

ax1.legend(ncol=5, fontsize='7.5')
ax1.grid(which='major', axis='y', color='gray', linestyle='--', linewidth=0.8)

ax2.legend(ncol=5, fontsize='7.5')
ax2.grid(which='major', axis='y', color='gray', linestyle='--', linewidth=0.8)

# fig.suptitle('A64FX (boost eco mode) with frtpx -O3 and SSL2 (BLAS/LAPACK)')
fig.suptitle('Fugaku (' + power_mode + ') with frtpx -O3 and SSL2 (BLAS/LAPACK) ' + compiler_version)
ofn = 'out.png'
plt.savefig(ofn, format='png')

