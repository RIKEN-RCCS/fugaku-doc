/* Copyright 2024 Research Organization for Information Science and Technology */
#ifndef __TIMER_H__
#define __TIMER_H__

double get_elp_time() ;
double get_cpu_time() ;

#endif /* __TIMER_H__ */
