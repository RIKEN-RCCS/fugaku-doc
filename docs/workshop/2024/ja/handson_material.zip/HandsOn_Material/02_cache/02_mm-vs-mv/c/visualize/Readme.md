```shell
$ bash 01collect.sh # Edit PREFIX if necessary, to change the location of the results.
$ ls 
out.csv (...)
$ python3 02viz.py out.csv
$ ls
out.png (...)
```
