```shell
$ bash 01convert2csv.sh ../P1.256MB
$ ls
P1.256MB.csv (...)
$ gnuplot < 02plot.gnuplot
```
