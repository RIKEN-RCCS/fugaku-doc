#!/bin/bash
#PJM -g hp240486
#PJM --rsc-list [resource_group]
#PJM --rsc-list "node=1,elapse=00:07:00"
#PJM --rsc-list "node-mem=28Gi"
#PJM --rsc-list "freq=2200, eco_state=2"
#PJM -x PJM_LLIO_GFSCACHE=/vol0006
#PJM -N "memrd"
#PJM -o  "%n.%j.out"
#PJM -e  "%n.%j.err"
#PJM -s


BINDIR=../../00_lmbench/lmbench-3.0-a9/bin/aarch64-linux-gnu
EXE=${BINDIR}/lat_mem_rd
CMDOPT=$(echo "-P 1 256 64 128 256 512 1024")
LOGFILE=$(echo "P1.256MB")

ulimit -s unlimited
numactl --physcpubind=12 --localalloc ${EXE} ${CMDOPT} &> ${LOGFILE}
